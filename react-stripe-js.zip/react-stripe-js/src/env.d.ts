// A magic global reflecting the current package version defined in
// `package.json`. This will be rewritten at build time as a string literal
// when rollup is run (via `@plugin/rollup-replace`).
declare const _VERSION: string;
