# Changelog

See the [releases page](https://github.com/stripe/react-stripe-js/releases) on
GitHub for release notes.
