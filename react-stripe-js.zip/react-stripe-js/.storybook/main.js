module.exports = {
  stories: ['./example.stories.js'],
  reactOptions: {
    strictMode: true,
  },
};
